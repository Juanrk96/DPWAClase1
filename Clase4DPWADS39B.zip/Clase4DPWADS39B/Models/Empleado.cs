﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Clase4DPWADS39B.Models;

public partial class Empleado
{
    //[Required(ErrorMessage = "El Cmapo Dui es obligatorio")]
    //[RegularExpression(@"^\d{8}-\d{1}", ErrorMessage =" El formato debe ser 0000000-0")]
    public int Dui { get; set; }

    public string Nombre { get; set; } = null!;

    public string Apodo { get; set; } = null!;

    public string Pass { get; set; } = null!;

    public string Nivel { get; set; } = null!;
}
