﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Clase4DPWADS39B.Models;

public partial class Ds39Context : DbContext
{
    public Ds39Context()
    {
    }

    public Ds39Context(DbContextOptions<Ds39Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Empleado> Empleados { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=DESKTOP-EGCRQCQ; Database=ds39; Trusted_Connection=True; Encrypt=False;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.Dui).HasName("PK__empleado__D876F1BE57D9F5C8");

            entity.ToTable("empleado");

            entity.Property(e => e.Dui)
                .ValueGeneratedNever()
                .HasColumnName("dui");
            entity.Property(e => e.Apodo)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("apodo");
            entity.Property(e => e.Nivel)
                .HasMaxLength(4)
                .IsUnicode(false)
                .HasColumnName("nivel");
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("nombre");
            entity.Property(e => e.Pass)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("pass");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
