create database ds39;
go

use ds39;
go

create table empleado(
dui int primary key,
nombre varchar(50) not null,
apodo varchar(50) not null,
pass varchar(50) not null,
nivel varchar(4) not null);


select * from empleado